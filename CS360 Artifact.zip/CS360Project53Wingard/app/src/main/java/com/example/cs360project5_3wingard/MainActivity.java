package com.example.cs360project5_3wingard;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.log_in_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView user = findViewById(R.id.editTextUsername);
        TextView pass = findViewById(R.id.editTextPassword);
        Button loginB = findViewById(R.id.LoginButton);
        loginB.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view) //LOGIN
            {
                if (user.getText().toString().equals("User43")) { //FUNCTIONAL USERNAME
                    if (pass.getText().toString().equals("Pass43")) { //FUNCTIONAL PASSWORD
                        setContentView(R.layout.dashboard);
                        Basics(savedInstanceState, "Dashboard");
                    }
                }
            }
        });
    }





    ArrayList<Product> productList = new ArrayList<Product>();
    ArrayList<Product> notifications = new ArrayList<Product>();
    void Basics(Bundle savedInstanceState, String type)
    {
        Button notiB = findViewById(R.id.NotificationButton);
        Button dashB = findViewById(R.id.DashboardButton);
        Button prodB = findViewById(R.id.ProductsButton);
        notiB.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                setContentView(R.layout.notifications);
                Basics(savedInstanceState, "Notifications");
            }
        });
        dashB.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                setContentView(R.layout.dashboard);
                Basics(savedInstanceState, "Dashboard");
            }
        });
        prodB.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                setContentView(R.layout.database_grid);
                Basics(savedInstanceState, "Products");
            }
        });

        updateNotifications();

        if (type.equals("Notifications"))
        {
            Notifications(savedInstanceState);
        }
        if (type.equals("Dashboard"))
        {
            Dashboard(savedInstanceState);
        }
        if (type.equals("Products"))
        {
            Products(savedInstanceState);
        }
    }




    boolean duplicateFound(String newItemName) //ENSURE NO DUPLICATES
    {
        for(int i=0; i<productList.size(); i++)
        {
            if((productList.get(i).getName().equals(newItemName)))
            {
                return true;
            }
        }
        return false;
    }

    int findProduct(String name) //FIND A SPECIFIC ITEM IN THE LIST
    {
        for(int i=0; i<productList.size(); i++)
        {
            if((productList.get(i).getName().equals(name)))
            {
                return i;
            }
        }
        return -1;
    }

    void updateNotifications() //UPDATE NOTIFICATION TEXT BOX AND LIST
    {
        TextView numNoti = findViewById(R.id.numNotif);
        notifications.clear();
        for(int i=0; i<productList.size(); i++) //FOR EACH ITEM IN THE PRODUCT LIST
        {
            if (productList.get(i).isLow()) //IF THE ITEM IS LOW (LESS THAN 10)
            {
                notifications.add(productList.get(i)); //ADD IT TO THE NOTIFICATIONS LIST
            }
        }
        numNoti.setText("Notifications: " + notifications.size()); //DISPLAY NUMBER OF LOW ITEMS
    }

    void addToProduct(int index, int x) //ADD X TO THE INDEXED PRODUCT'S AMOUNT
    {
        (productList.get(index)).increaseByX(x);
    }

    int getNumber(String strNum) //SINCE PARSE_INT CRASHES EVERYTHING
    {
        if (strNum.equals(""))
        {
            strNum = "0";
        }
        for (int i=0; i<9999; i++) //CHECK UP TO 9999 NUMBERS
        {
            String test = Integer.toString(i); //CONVERT THE INDEX TO A STRING
            if (test.equals(strNum)) //COMPARE IT TO THE VARIABLE
            {
                return i; //AND RETURN IT IF THEY ARE EQUAL
            }
        }
        return 0;
    }
    void Notifications(Bundle savedInstanceState)
    {
        for(int i=0; i<notifications.size(); i++)
        {
            TableLayout notificationsTable = (TableLayout) findViewById(R.id.tableNotifications);

            /*PRINT NOTIFICATION LIST*/
            TableRow tr = new TableRow(notificationsTable.getContext());
            tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));

            TextView label_Name = new TextView(tr.getContext());
            label_Name.setText(notifications.get(i).getName() + " is low on stock");

            TextView label_Amount = new TextView(tr.getContext());
            label_Amount.setText(String.valueOf(notifications.get(i).getAmount()));

            Button button_Add = new Button(tr.getContext());
            button_Add.setId(i);
            button_Add.setText("+X");
            button_Add.setOnClickListener(new View.OnClickListener() //ON CLICK, ADD X TO INDEXED
            {
                public void onClick(View view)
                {
                    EditText etX = findViewById(R.id.increaseAmount);
                    String strX = etX.getText().toString();
                    int intX = getNumber(strX);

                    //USE THE BUTTON ID TO FIND A PRODUCT'S NAME IN THE NOTIFICATIONS LIST
                    String productName = (notifications.get(button_Add.getId())).getName();
                    //USE THE PRODUCT NAME TO GET THE INDEX IN THE PRODUCT LIST
                    int index = findProduct(productName);
                    //INCREASE THE AMOUNT IN THE PRODUCT LIST
                    addToProduct(index, intX);
                    //UPDATE THE NOTIFICATION LIST
                    setContentView(R.layout.notifications);
                    Basics(savedInstanceState, "Notifications");
                }
            });

            tr.addView(label_Name);
            tr.addView(label_Amount);
            tr.addView(button_Add);

            notificationsTable.addView(tr, new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));
        }

    }





    void Dashboard(Bundle savedInstanceState)
    {

    }





    void deleteProduct(int index)
    {
        if ( (productList.get(index)).hasZeroLeft() )
        {
            productList.remove(productList.get(index));
        }
    }

    void removeOne(int index)
    {
        (productList.get(index)).decreaseByX(1);
        deleteProduct(index);
    }

    void Products(Bundle savedInstanceState)
    {
        Button newProduct = findViewById(R.id.NewItemButton);
        TableLayout productTable = (TableLayout) findViewById(R.id.tableProducts);

        //DISPLAY LIST ON TABLE
        for(int i=0; i<productList.size(); i++)
        {
            TableRow tr = new TableRow(productTable.getContext());
            tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));
            TextView label_Name = new TextView(tr.getContext());
            label_Name.setText(productList.get(i).getName());
            TextView label_Description = new TextView(tr.getContext());
            label_Description.setText(productList.get(i).getDescription());
            TextView label_Amount = new TextView(tr.getContext());
            label_Amount.setText(String.valueOf(productList.get(i).getAmount()));
            Button button_Delete = new Button(tr.getContext());
            button_Delete.setId(i);
            button_Delete.setText("-1");
            button_Delete.setOnClickListener(new View.OnClickListener() //ON CLICK, ADD X TO INDEXED
            {
                public void onClick(View view)
                {
                    //USE THE BUTTON ID TO FIND THE PRODUCT ID
                    removeOne(button_Delete.getId());
                    setContentView(R.layout.database_grid);
                    Basics(savedInstanceState, "Products");
                }
            });
            tr.addView(label_Name);
            tr.addView(label_Description);
            tr.addView(label_Amount);
            tr.addView(button_Delete);
            productTable.addView(tr, new TableLayout.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));
        }

        //ON CLICK, ADD ITEM TO LIST
        newProduct.setOnClickListener(new View.OnClickListener()
            {
                public void onClick(View view)
                {
                    EditText newName = findViewById(R.id.editName);
                    EditText newDescription = (findViewById(R.id.editDescription));
                    EditText newAmount = (findViewById(R.id.editAmount));
                    String strN = (newName.getText()).toString();
                    String strD = (newDescription.getText()).toString();
                    String strA = (newAmount).getText().toString();



                    int intA = getNumber(strA);

                    if ( (strN.equals("")) || (intA == 0)) //IF THE FIELDS ARE INVALID
                    {
                        //DO NOTHING
                    }
                    else if (duplicateFound(strN)) //IF IT ALREADY EXISTS
                    {
                        int index = findProduct(strN); //FIND THE ORIGINAL
                        addToProduct(index, intA); //AND ADD THEM TO IT
                    }
                    else
                    {
                        Product newObject = new Product(strN, strD, intA);
                        productList.add(newObject); //ADD THE ITEM TO THE LIST
                    }
                    setContentView(R.layout.database_grid);
                    Basics(savedInstanceState, "Products");
                }
            });
    }



}