package com.example.cs360project5_3wingard;

public class Product
{
    String Name;
    String Description;
    int Amount;

    public Product()
    {
        Name = "name";
        Description = "desc";
        Amount = 0;
    }

    public Product(String newName, String newDescription, int newAmount)
    {
        Name = newName;
        Description = newDescription;
        Amount = newAmount;
    }

    void setName(String newName)
    {
        Name = newName;
    }
    String getName()
    {
        return Name;
    }

    void setDescription(String newDesc)
    {
        Description = newDesc;
    }
    String getDescription()
    {
        return Description;
    }

    int getAmount()
    {
        return Amount;
    }

    void increaseByX(int x)
    {
        Amount+=x;
    }

    void decreaseByX(int x)
    {
        Amount-=x;
    }

    boolean isLow()
    {
        if (Amount<10)
        {
            return true;
        }
        return false;
    }

    boolean hasZeroLeft()
    {
        if (Amount <= 0)
        {
            return true;
        }
        return false;
    }
}
