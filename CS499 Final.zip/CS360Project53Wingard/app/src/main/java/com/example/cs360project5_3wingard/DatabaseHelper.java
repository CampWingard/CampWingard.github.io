package com.example.cs360project5_3wingard;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "AccountsDatabase.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "all_accounts";
    private static final String COL_1_ID = "ID";
    private static final String COL_2_USER = "USERNAME";
    private static final String COL_3_PASS = "PASSWORD";
    private static final String COL_4_PROD_LIST = "PRODUCTS_LIST";
    private static final String COL_5_STOR_LIST = "STORAGE_LIST";
    private static final String COL_6_NOTI_LIST = "NOTIFICATIONS_LIST";
    private static final String COL_7_ORDE_LIST = "ORDERS_LIST";
    private static final String COL_8_HIST_LIST = "HISTORY_LIST";
    private static final String COL_9_HIST_MAX = "HISTORY_MAX";


    public DatabaseHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String createTableStatement = "CREATE TABLE " +TABLE_NAME+ " ("
                +COL_1_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
                +COL_2_USER+" TEXT, "
                +COL_3_PASS+" TEXT, "
                +COL_4_PROD_LIST+" TEXT, "
                +COL_5_STOR_LIST+" TEXT, "
                +COL_6_NOTI_LIST+" TEXT, "
                +COL_7_ORDE_LIST+" TEXT, "
                +COL_8_HIST_LIST+" TEXT, "
                +COL_9_HIST_MAX+" INT "
                +")";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }



    public boolean addAccount(Account newAccount)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COL_2_USER, newAccount.getUsername());
        cv.put(COL_3_PASS, newAccount.getPassword());

        long insert = db.insert(TABLE_NAME, null, cv);
        if (insert == -1)
        {
            db.close();
            return false;
        }
        else
        {
            db.close();
            return true;
        }
    }

    public void updateAccount(Account myAccount, String updateType)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        String whereClause;
        String[] whereArgs;

        if (updateType.equals("Products"))
        {
            cv.put(COL_4_PROD_LIST, productArrayListToString(myAccount.getProductList()));
            cv.put(COL_6_NOTI_LIST, productArrayListToString(myAccount.getNotificationsList()));
        }
        else if (updateType.equals("Storage"))
        {
            cv.put(COL_5_STOR_LIST, stringArrayListToString(myAccount.getStorageList()));
        }
        else if (updateType.equals("Orders"))
        {
            cv.put(COL_7_ORDE_LIST, productArrayListToString(myAccount.getOrdersList()));
        }
        else if (updateType.equals("History"))
        {
            cv.put(COL_8_HIST_LIST, stringArrayListToString(myAccount.getHistoryList()));
        }
        else if (updateType.equals("HistoryMax"))
        {
            cv.put(COL_9_HIST_MAX, myAccount.getMaxHistory());
        }
        db.update(TABLE_NAME, cv, COL_1_ID +" = "+ myAccount.getID(), null);
        db.close();
    }

    public void deleteAccount(int index)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL(" DELETE FROM " + "all_accounts" + " WHERE " + COL_1_ID + "=\"" + index + "\";");

        db.close();
    }

    public void deleteAccount(String username)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL(" DELETE FROM " + "all_accounts" + " WHERE " + COL_2_USER + "=\"" + username+ "\";");

        db.close();
    }

    public void nullify(int ID, String column)
    {

    }

    ArrayList<String> stringToStringArrayList(String data)
    {
        ArrayList<String> arrayListS = new ArrayList<>();
        boolean writing = false;
        StringBuilder sb = new StringBuilder();

        for (int i=0; i<data.length(); i++)
        {
            char character = data.charAt(i);
            if (writing && data.length() != 2)
            {
                if (character != ']')
                {
                    sb.append(character);
                }
                else
                {
                    arrayListS.add(sb.toString());
                    sb.setLength(0);
                    writing = false;
                }
            }
            if (character == '[')
            {
                writing = true;
                sb = new StringBuilder();
            }
        }

        return arrayListS;
    }

    ArrayList<Product> stringToProductArrayList(String data)
    {
        ArrayList<Product> arrayListP = new ArrayList<>();
        boolean writing = false;
        StringBuilder sb = new StringBuilder();
        int dataNum = 1;
        Product myProduct = new Product();

        for (int i=0; i<data.length(); i++)
        {
            char character = data.charAt(i);
            if (writing && data.length() != 2)
            {

                if (character != ']' && character != ',')
                {
                    sb.append(character);
                }
                else if (character != ']')
                {
                    if (dataNum == 1)
                    {
                        myProduct.setName(sb.toString());
                        sb.setLength(0);
                        dataNum++;
                    }
                    else if (dataNum == 2)
                    {
                        String myStorage = sb.toString();
                        myProduct.setStorage(myStorage);
                        sb.setLength(0);
                        dataNum++;
                    }
                }
                else
                {
                    int myAmount = Integer.parseInt( sb.toString() );
                    myProduct.setAmount(myAmount);
                    arrayListP.add(myProduct);

                    sb.setLength(0);
                    dataNum = 1;
                    writing = false;
                }
                //Log.i("Array Return", sb.toString());
            }

            if (character == '[')
            {
                myProduct = new Product();
                writing = true;
            }
        }

        return arrayListP;
    }

    String stringArrayListToString(ArrayList<String> data)
    {
        StringBuilder sb = new StringBuilder();

        for (int i=0; i<data.size(); i++)
        {
            if(data.get(i) != null && !data.get(i).isEmpty())
            {
                sb.append("[");
                sb.append(data.get(i));
                sb.append("]");
            }
        } //String = "[data][data][data]"

        if (sb.length() == 0)
        {
            sb.append("[]");
        }
        return sb.toString();
    }

    String productArrayListToString(ArrayList<Product> data)
    {
        StringBuilder sb = new StringBuilder();

        for (int i=0; i<data.size(); i++)
        {
            sb.append("[");
            sb.append(data.get(i).getName());
            sb.append(",");
            sb.append(data.get(i).getStorage());
            sb.append(",");
            sb.append(data.get(i).getAmount());
            sb.append("]");
        } //String = "[dataName,dataStorage,dataAmount][dataName,dataStorage,dataAmount]"

        if (sb.length() == 0)
        {
            sb.append("[]");
        }
        return sb.toString();
    }



    Account getAccount(int index)
    {
        Account selectedAccount;
        String queryString = "SELECT * FROM "+TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst())
        {
            int rowNumber = 1;
            do{
                if (index == rowNumber)
                {
                    int ID = cursor.getInt(0);
                    String username = cursor.getString(1);
                    String password = cursor.getString(2);
                    //FIX ME string to ArrayList
                    String products_list = cursor.getString(3);
                    ArrayList<Product> prodList = new ArrayList<>();
                    if (products_list != null)
                    {
                        prodList = stringToProductArrayList(products_list);
                    }
                    Log.i("Check Return", products_list);

                    String storage_list = cursor.getString(4);
                    ArrayList<String> storList = new ArrayList<>();
                    if (storage_list != null)
                    {
                        storList = stringToStringArrayList(storage_list);
                    }
                    Log.i("Check Return", storage_list);

                    String notifications_list = cursor.getString(5);
                    ArrayList<Product> notiList = new ArrayList<>();
                    if (notifications_list != null)
                    {
                        notiList = stringToProductArrayList(notifications_list);
                    }
                    Log.i("Check Return", notifications_list);

                    String orders_list = cursor.getString(6);
                    ArrayList<Product> ordeList = new ArrayList<>();
                    if (orders_list != null)
                    {
                        ordeList = stringToProductArrayList(orders_list);
                    }
                    Log.i("Check Return", orders_list);

                    String history_list = cursor.getString(7);
                    ArrayList<String> histList = new ArrayList<>();
                    if (history_list != null)
                    {
                        histList = stringToStringArrayList(history_list);
                    }
                    Log.i("Check Return", history_list);

                    String history_max = cursor.getString(8);
                    int histMax = 10;
                    if (history_max != null)
                    {
                        histMax = Integer.parseInt(history_max);
                    }
                    Log.i("Check Return", String.valueOf(histMax));

                    selectedAccount = new Account(ID, username, password, prodList, storList, notiList, ordeList, histList, histMax);
                    cursor.close();
                    db.close();

                    return selectedAccount;
                }
                rowNumber++;
            } while (cursor.moveToNext());
        }
        else
        {
            // failure. empty list
        }
        cursor.close();
        db.close();
        selectedAccount = new Account();
        return selectedAccount;
    }


    ArrayList<String> getAllIDs()
    {
        ArrayList<String> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM "+TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();


        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst())
        {
            do{
                String username = cursor.getString(0);

                returnList.add(username);
            } while (cursor.moveToNext());
        }
        else
        {
            // failure. empty list
        }
        cursor.close();
        db.close();
        return returnList;
    }

    ArrayList<String> getAllUsernames()
    {
        ArrayList<String> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM "+TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();


        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst())
        {
            do{
                String username = cursor.getString(1);

                returnList.add(username);
            } while (cursor.moveToNext());
        }
        else
        {
            // failure. empty list
        }
        cursor.close();
        db.close();
        return returnList;
    }

    ArrayList<String> getAllPasswords()
    {
        ArrayList<String> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM "+TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();


        Cursor cursor = db.rawQuery(queryString, null);
        if (cursor.moveToFirst())
        {
            do{
                String password = cursor.getString(2);

                returnList.add(password);
            } while (cursor.moveToNext());
        }
        else
        {
            // failure. empty list
        }
        cursor.close();
        db.close();
        return returnList;
    }
}
