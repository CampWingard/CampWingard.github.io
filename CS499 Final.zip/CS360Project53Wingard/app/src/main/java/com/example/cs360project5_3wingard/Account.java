package com.example.cs360project5_3wingard;

import java.util.ArrayList;

//CS499 Category Two / Three
//LOOK UP Android Studio SQLite
public class Account
{
    int ID;
    String username;
    String password;
    int historyMax;
    ArrayList<Product> productList = new ArrayList<Product>();
    ArrayList<String> storageList = new ArrayList<String>();
    ArrayList<Product> notifications = new ArrayList<Product>();
    ArrayList<Product> orders = new ArrayList<Product>();
    ArrayList<String> history = new ArrayList<String>();

    public Account()
    {
        username = "null";
        password = "null";
        historyMax = 0;
    }

    public Account(String user, String pass)
    {
        username = user;
        password = pass;
        historyMax = 10;
    }

    public Account(int id, String user, String pass, ArrayList<Product> prodList, ArrayList<String> storList, ArrayList<Product> notiList, ArrayList<Product> ordeList, ArrayList<String> histList, int histMax)
    {
        ID = id;
        username = user;
        password = pass;
        productList = prodList;
        storageList = storList;
        notifications = notiList;
        orders = ordeList;
        history = histList;
        historyMax = histMax;
    }

    void setID(int newID){ ID = newID; }
    int getID(){ return ID; }

    void setUsername(String newUser)
    {
        username = newUser;
    }
    String getUsername()
    {
        return username;
    }

    void setPassword(String newPass)
    {
        password = newPass;
    }
    String getPassword()
    {
        return password;
    }

    void setMaxHistory(int newMax)
    {
        historyMax = newMax;
    }
    int getMaxHistory()
    {
        return historyMax;
    }



    void setProductList(ArrayList<Product> newList)
    {
        productList = newList;
    }
    ArrayList<Product> getProductList()
    {
        return productList;
    }

    void setStorageList(ArrayList<String> newList)
    {
        storageList = newList;
    }
    ArrayList<String> getStorageList()
    {
        return storageList;
    }

    void setNotificationsList(ArrayList<Product> newList)
    {
        notifications = newList;
    }
    ArrayList<Product> getNotificationsList()
    {
        return notifications;
    }

    void setOrdersList(ArrayList<Product> newList)
    {
        orders = newList;
    }
    ArrayList<Product> getOrdersList()
    {
        return orders;
    }

    void setHistoryList(ArrayList<String> newList)
    {
        history = newList;
    }
    ArrayList<String> getHistoryList()
    {
        return history;
    }
}
