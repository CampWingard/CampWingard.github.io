package com.example.cs360project5_3wingard;

public class Product
{
    String Name;
    String Storage;
    int Amount;

    public Product()
    {
        Name = "name";
        Storage = "None";
        Amount = 0;
    }

    public Product(String newName, String newStorage, int newAmount)
    {
        Name = newName;
        Storage = newStorage;
        Amount = newAmount;
    }

    void setName(String newName)
    {
        Name = newName;
    }
    String getName()
    {
        return Name;
    }

    void setStorage(String newStorage) { Storage = newStorage; }
    String getStorage()
    {
        return Storage;
    }

    int getAmount()
    {
        return Amount;
    }
    void setAmount(int newAmount) { Amount = newAmount; }

    void increaseByX(int x)
    {
        Amount+=x;
    }

    void decreaseByX(int x)
    {
        Amount-=x;
    }

    boolean isLow()
    {
        if (Amount<10)
        {
            return true;
        }
        return false;
    }

    boolean hasZeroLeft()
    {
        if (Amount <= 0)
        {
            return true;
        }
        return false;
    }
}
